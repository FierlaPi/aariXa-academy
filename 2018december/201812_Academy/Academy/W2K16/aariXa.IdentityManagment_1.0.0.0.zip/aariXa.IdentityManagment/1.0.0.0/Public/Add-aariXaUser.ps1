﻿Import-Module ActiveDirectory

<#
.Synopsis
    Create a user in AD and put in Group
.DESCRIPTION
    Create a user based on the given attributes, activate them and put it in a OU.
    Then the user is also added to a group depending on his department
.EXAMPLE
    Add-aariXaUser -FirstName "Alice" -LastName "Quinn" -Phone "+32498123456" -Title "System Engineer" -Department "Infrastructuur"
    Create a user with the name Alice Quinn in AD and add it to the Infrastructure group
.EXAMPLE
    (Import-CSV .\NewUsers.csv) | Add-aariXaUser
    Create users found in the NewUser.csv. The csv headers should correspond to the parameter names
.INPUTS
    FirstName : Users first name
    LastName  : Users last name
    Phone     : Users phone number
    Title     : Users job title
    Department: Users department
.FUNCTIONALITY
    User managment
#>
function Add-aariXaUser {
    [CmdletBinding(DefaultParameterSetName='Parameter Set 1', 
        SupportsShouldProcess=$true, 
        PositionalBinding=$false,
        HelpUri = 'http://www.aarixa.be/',
        ConfirmImpact='Medium')]
    [Alias()]
    Param
    (
        # Users First Name
        [Parameter(Mandatory=$true, 
            ValueFromPipeline=$true,
            ValueFromPipelineByPropertyName=$true, 
            ValueFromRemainingArguments=$false, 
            Position=0,
            ParameterSetName='Parameter Set 1')]
        [ValidateNotNull()]
        [ValidateNotNullOrEmpty()]
        [Alias("fn")] 
        [String]$FirstName,
 
        # Users Last Name
        [Parameter(Mandatory=$true, 
            ValueFromPipeline=$true,
            ValueFromPipelineByPropertyName=$true, 
            ValueFromRemainingArguments=$false, 
            Position=1,
            ParameterSetName='Parameter Set 1')]
        [ValidateNotNull()]
        [ValidateNotNullOrEmpty()]
        [Alias("ln")] 
        [String]$LastName,

        # Users Phone
        [Parameter(Mandatory=$true, 
            ValueFromPipeline=$true,
            ValueFromPipelineByPropertyName=$true, 
            ValueFromRemainingArguments=$false, 
            Position=2,
            ParameterSetName='Parameter Set 1')]
        [ValidateNotNull()]
        [ValidateNotNullOrEmpty()]
        [Alias("ph")]
        [String]$Phone,

        # Users Job Title
        [Parameter(Mandatory=$true, 
            ValueFromPipeline=$true,
            ValueFromPipelineByPropertyName=$true, 
            ValueFromRemainingArguments=$false, 
            Position=3,
            ParameterSetName='Parameter Set 1')]
        [ValidateNotNull()]
        [ValidateNotNullOrEmpty()]
        [Alias("jt")]
        [String]$Title,

        # Users Department
        [Parameter(Mandatory=$true, 
            ValueFromPipeline=$true,
            ValueFromPipelineByPropertyName=$true, 
            ValueFromRemainingArguments=$false, 
            Position=4,
            ParameterSetName='Parameter Set 1')]
        [ValidateNotNull()]
        [ValidateNotNullOrEmpty()]
        [ValidateSet("Infrastructure", "Development", "Sales", "Managment")]
        [Alias("d")]
        [String]$Department
    )
 
    Begin {
        Write-Output "Start user creation"
    }

    Process {
        if ($pscmdlet.ShouldProcess($("Active Directory of " + (Get-ADDomain).Name), "Create")) {
            $cleanLastName = Remove-Composed $LastName
            $cleanLastName = Remove-Diacritics $cleanLastName
            $cleanLastName = $cleanLastName.replace(' ','')

            $cleanFirstName = Remove-Composed $FirstName
            $cleanFirstName = Remove-Diacritics $cleanFirstName
            $cleanFirstName = $cleanFirstName.replace(' ','')

            if ($cleanLastName.Length -ge 6) {
                $SAN = ($($cleanLastName.Substring(0, 6) + $cleanFirstName.Substring(0, 2))).ToLower()
            } else {
                $SAN = ($($cleanLastName + $cleanFirstName.Substring(0, (8 - $cleanLastName.Length)))).ToLower()
            }

            $prefix = ($($cleanFirstName + '.' + $cleanLastName)).ToLower()
            Write-Verbose $("Cleaned prefix: " + $prefix)

            $param = @{
                'GivenName'         = $FirstName
                'Surname'           = $LastName
                'Name'              = $($FirstName + ' ' + $LastName)
                'DisplayName'       = $($LastName + ' ' + $FirstName)
                'EmailAddress'      = $($prefix + '@aarixa.be')
                'OfficePhone'       = $Phone
                'Title'             = $Title
                'Company'           = 'aariXa'
                'Department'        = $Department
                'City'              = 'Herk de Stad'
                'Country'           = 'BE'
                'SamAccountName'    = $SAN
                'UserPrincipalName' = $($prefix + '@aarixaacademy.local')
                'AccountPassword'   = (ConvertTo-SecureString -String "P@ssW0rd000" -AsPlainText -Force)
                'Path'              = 'OU=Users,OU=aariXa,DC=aariXaAcademy,DC=local'
                'Enabled'           = $true
            }
            New-ADUser @param
            Write-Verbose $("`tAdded " + $FirstName + " " + $LastName + " to domain")

            Add-ADGroupMember -Identity $Department -Members $SAN
            Write-Verbose $("`tAdded " + $FirstName + " " + $LastName + " to group " + $Department)
        }
    }

    End {
        Write-Output "End user creation"
    }
}