﻿<#
.Synopsis
   Remove Diacritics characters
.DESCRIPTION
   Removes special characters and combined characters from a string and replace it with ASCII characters
.EXAMPLE
   Remove-Diacritict -src "ÄéèàçßæäãâåêëìíîïñòóôõöâùúûüýÿĀāĂăœŒ"

   Will return "AeeacssaeaaaaeeiiiinoooooauuuuyyAaAaoeOe"
#>
function Remove-Composed {
    param (
        [String]$src = [String]::Empty
    )

    $charmap = @(
        "ß", "ss"
        "æ", "ae"
        "Œ", "Oe"
        "œ", "oe"
        "ü", "oe"
    )

    $retVal = $src

    for([int]$i = 0; $i -lt $charmap.length; $i +=2) {
        $retVal = $retVal -creplace $charmap[$i],$charmap[$i + 1]
    }

    $retVal
}
