﻿<#
.Synopsis
   Remove Diacritics characters
.DESCRIPTION
   Removes special characters and combined characters from a string and replace it with ASCII characters
.EXAMPLE
   Remove-Diacritict -src "ÄéèàçßæäãâåêëìíîïñòóôõöâùúûüýÿĀāĂăœŒ"

   Will return "AeeacssaeaaaaeeiiiinoooooauuuuyyAaAaoeOe"
#>
function Remove-Diacritics {
    param (
        [String]$src = [String]::Empty
    )

    $normalized = $src.Normalize( [Text.NormalizationForm]::FormD )
    $sb = new-object Text.StringBuilder
    $normalized.ToCharArray() | ForEach-Object { 
        if( [Globalization.CharUnicodeInfo]::GetUnicodeCategory($_) -ne [Globalization.UnicodeCategory]::NonSpacingMark) {
            [void]$sb.Append($_)
        }
    }
    $sb.ToString()
}
